package view;
/**
 * Класс view проекта
 * @author Разноглазов Никита ПИН-24
 *
 */
public class View {

    public static void view(String msg){
        System.out.println(msg);
    }
}
