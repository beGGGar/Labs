package model;


public interface IControlledInput {
	public Object addNew();
	public void changeExisting(Object smth);
}
